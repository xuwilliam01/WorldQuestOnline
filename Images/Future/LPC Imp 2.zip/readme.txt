11:45 PM 1/8/2014 William.Thompsonj

Attribute Stephen "Redshrike" Challener as graphic artist and William.Thompsonj as contributor. If reasonable, also link to OpenGameArt.org